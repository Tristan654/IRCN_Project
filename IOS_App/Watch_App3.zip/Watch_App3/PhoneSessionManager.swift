//
//  PhoneSessionManager.swift
//  Watch_App3
//
//  Created by Nagai-lab UTokyo on 2025/05/16.
//

import SwiftUI
import WatchConnectivity


 

class PhoneSessionManager: NSObject, WCSessionDelegate, ObservableObject {
    @Published var receivedHeartRate: Double = 0.0
    @Published var receivedHRV: Double = 0.0
    @Published var receivedRrate: Double = 0.0
    @Published var receivedStartCSV: Bool = false
    @Published var ListvalueBpm:[Double] = []
    @Published var ListvalueHRV:[Double] = []
    @Published var ListvalueRrate:[Double] = []
    let startCSV = CreationCsvFile()
    
    override init() {//if I have a parent and want to redefine a class that already exist i need override
        super.init()
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
    }
    
    //real time message if session is reachable
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        DispatchQueue.main.async {
                if self.receivedStartCSV == false {
                    self.receivedStartCSV = true
                    print(" 🗃️ CSV File Start Data Collection ...")
                }
            }
        if let heartRate = message["heartRate"] as? Double {
            DispatchQueue.main.async {
                self.receivedHeartRate = heartRate
                print("Receive by the iPhone (Heart rate): \(heartRate) bpm")
                self.ListvalueBpm.append(heartRate)
                //print(self.ListvalueBpm)
            }
        }
        if let HRV = message["hrv"] as? Double {
            DispatchQueue.main.async {
                self.receivedHRV = HRV
                print("Receive by the iPhone (HRV) : \(HRV) ms")
                self.ListvalueHRV.append(HRV)
            }
        }
        if let Rrate = message["respiratoryRate"] as? Double {
            DispatchQueue.main.async {
                self.receivedRrate = Rrate
                print("Receive by the iPhone (Rrate) : \(Rrate) bpm")
                self.ListvalueRrate.append(Rrate)
                if (self.receivedStartCSV == true) {
                    self.startCSV.createCsvFile(with: self)
                }
            }
        }
        
    }
    func sessionDidBecomeInactive(_ session: WCSession) {}
    func sessionDidDeactivate(_ session: WCSession) {}
    func sessionWatchStateDidChange(_ session: WCSession) {}
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {}
}

