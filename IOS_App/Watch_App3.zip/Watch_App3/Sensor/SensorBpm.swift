import SwiftUI
import Charts

struct SensorBpm: View {
    @EnvironmentObject var phoneSessionManager: PhoneSessionManager
    @State var CsvValue = false
    var body: some View {
        NavigationStack{
            VStack(spacing: 30) {
                
                
                VStack(spacing: 6) {
                    Text("Heart Rate")
                        .font(.system(size: 32, weight: .semibold))
                        .foregroundColor(.primary)
                    
                    Text("BPM Live Data")
                        .font(.title3)
                        .foregroundColor(.gray)
                }
                .padding(.top, 40)
                
                
                Text("\(Int(phoneSessionManager.receivedHeartRate)) bpm")
                    .font(.system(size: 48, weight: .bold))
                    .foregroundColor(.red)
                
                // Graphique en dessous
                Chart {
                    ForEach(Array(phoneSessionManager.ListvalueBpm.enumerated()), id: \.offset) { index, bpm in
                        LineMark(
                            x: .value("Time", index),
                            y: .value("BPM", bpm)
                        )
                        .interpolationMethod(.catmullRom)
                        .foregroundStyle(Color.red)
                    }
                }
                .frame(height: 200)
                .padding(.horizontal, 24)
                .chartYScale(domain: 0...150)
                .chartXAxis {
                    AxisMarks()
                }
                .chartYAxis {
                    AxisMarks(position: .leading)
                }
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            //.background(Color(UIColor.systemGroupedBackground))
            StyleButton(title: "CSV FILE") {
                CsvValue = true
            }.padding(.bottom, 200)
            NavigationLink(destination: CsvFileListView(), isActive: $CsvValue) { EmptyView() }.hidden()
        }
    }
}
