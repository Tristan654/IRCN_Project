import SwiftUI
import WatchConnectivity

struct ContentView: View {
    @State var BpmValue = false
    @State var CsvValue = false
    @State var RespiratoryRateValue = false
    @State var HRVValue = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                VStack(spacing: 8) {
                    Text("Sensors Data")
                        .font(.system(size: 36, weight: .semibold))
                        .foregroundColor(.primary)
                    
                    Text("Choose a sensor")
                        .font(.title3)
                        .foregroundColor(.gray)
                }
                .padding(.top, 80)
                
                Spacer()
                
                // Boutons
                VStack(spacing: 30) {
                    StyleButton2(title: "BPM") {
                        BpmValue = true
                    }

                    StyleButton2(title: "HRV") {
                        HRVValue = true
                    }

                    StyleButton2(title: "Respiratory Rate") {
                        RespiratoryRateValue = true
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 80)

                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(UIColor.systemGroupedBackground))
            
            // Navigation
            NavigationLink(destination: SensorBpm(), isActive: $BpmValue) { EmptyView() }.hidden()
            NavigationLink(destination: SensorHRV(), isActive: $HRVValue) { EmptyView() }.hidden()
            NavigationLink(destination: SensorRespiratoryRate(), isActive: $RespiratoryRateValue) { EmptyView() }.hidden()
            NavigationLink(destination: CsvFileListView(), isActive: $CsvValue) { EmptyView() }.hidden()
        }
    }
}

#Preview {
    ContentView()
}

