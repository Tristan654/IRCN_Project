//
//  Untitled.swift
//  Watch_App3
//
//  Created by Nagai-lab UTokyo on 2025/05/30.
//

import SwiftUI
import Foundation



class CreationCsvFile: NSObject, ObservableObject {
    @Published var lignes: [[Double]] = []
    var BoolStartCsv : Bool = true
    var BoolUrl : Bool = true
    var fileName: String = ""
    func createCsvFile(with phoneSessionManager: PhoneSessionManager) {
        lignes.append([phoneSessionManager.receivedHeartRate, phoneSessionManager.receivedHRV,phoneSessionManager.receivedRrate])
        //convert in String because joined work only with String
        let stringData = lignes.map { row in
            row.map { String($0) }
        }
        let csvString = stringData.map { $0.joined(separator: ",") }.joined(separator: "\n")//convert in csv
       
        if (BoolStartCsv == true){
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd_HH-mm"
            fileName = dateFormatter.string(from: Date())
            BoolStartCsv = false
        }
        if let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            let fileURL = documentsDirectory.appendingPathComponent("\(fileName).csv")
            do {
                try csvString.write(to: fileURL, atomically: true, encoding: .utf8)
                if (BoolUrl == true){
                    print("The CSV File has been created here : \(fileURL.path)")
                }
                BoolUrl = false
            } catch {
                print("Reading Error : \(error)")
            }
        }
    }
}
