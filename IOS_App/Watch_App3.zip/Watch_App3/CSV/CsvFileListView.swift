//
//  CsvFileListView.swift
//  Watch_App3
//
//  Created by Nagai-lab UTokyo on 2025/06/02.
//

import SwiftUI

struct CsvFileListView: View{
    @State private var csvFiles: [URL] = []
    @State private var selectedFileContent: String = ""
    @State private var selectedFileURL: URL?
    @State private var showShareSheet: Bool = false
    var body:some View{
        VStack {
            List(csvFiles, id: \.self) { file in
                Button(action: {loadContent(of: file)}) {
                    Text(file.lastPathComponent)
                }
                .swipeActions {
                    Button(role: .destructive) {
                        deleteFile(of: file)
                    } label: {
                        Label("Delete", systemImage: "trash")
                    }
                }
            }
            if !selectedFileContent.isEmpty {
                ScrollView {
                    Text(selectedFileContent)
                        .padding()
                }
                .frame(height: 200)
            }

            Button("Share the file") {
                showShareSheet = true
            }
            .padding()
            .disabled(selectedFileURL == nil)
        }
        .onAppear(){loadCsv()}
        .sheet/*modal view liding up from the bottom of the screen*/(isPresented: $showShareSheet) {
            if let url = selectedFileURL {
                ShareSheet(activityItems: [url])
            }
        }
        .navigationTitle("CSV File")
    }
    func loadCsv() {
        let fileManager = FileManager.default
        if let docURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first {
            do {
                let files = try fileManager.contentsOfDirectory(at: docURL, includingPropertiesForKeys: nil)
                csvFiles = files.filter { $0.pathExtension.lowercased() == "csv" }
                } catch {
                    print("Folder Error: \(error)")
                }
            }
        }
    func loadContent(of file: URL) {
            do {
                selectedFileContent = try String(contentsOf: file, encoding: .utf8)
                selectedFileURL = file
            } catch {
                selectedFileContent = "Error File: \(error.localizedDescription)"
                selectedFileURL = nil
            }
        }
    func deleteFile(of file: URL) {
        do {
            try FileManager.default.removeItem(at: file)
            loadCsv() // Reload the file list
        } catch {
            print("Error Delate : \(error)")
        }
    }
}

// Allow to share CSV File using UIKit
struct ShareSheet: UIViewControllerRepresentable {
    var activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
