//
//  Watch_App3App.swift
//  Watch_App3
//
//  Created by Nagai-lab UTokyo on 2025/05/12.
//

import SwiftUI

@main
struct Watch_App3App: App {
    @StateObject var phoneSessionManager = PhoneSessionManager()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(phoneSessionManager)//work only with struct view elsewhere you can't use
        }
    }
}
