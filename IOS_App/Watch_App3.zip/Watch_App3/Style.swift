//
//  Style.swift
//  Watch_App3
//
//  Created by Nagai-lab UTokyo on 2025/05/21.
//
import SwiftUI


// Retrieve on Internet
struct StyleButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .frame(width: 200, height: 45)
                .foregroundColor(.white)
                .background(
                    Capsule()
                        .fill(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.gray, Color.red]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                )
                .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 3)
        }
    }
}


struct StyleButton2: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 28, weight: .semibold))
                .foregroundColor(.black)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 24)
                        .fill(Color.white)
                        .shadow(color: .gray.opacity(0.2), radius: 10, x: 0, y: 5)
                )
        }
        .frame(width: 300, height: 100)
    }
}

